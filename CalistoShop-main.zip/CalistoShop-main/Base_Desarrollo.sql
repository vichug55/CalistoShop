CREATE TABLE articulos (
    id           int(11) PRIMARY KEY AUTO_INCREMENT,
    nombre       varchar(70) NOT NULL,
    tipo_de_ato  varchar(70) NOT NULL,
    descripcion  varchar(70) NOT NULL,
    imagen       varchar(200),
    talla        varchar(70),
    col_id       int(11),
    precio       int(30) NOT NULL,
    cat_id       int(11) NOT NULL,
    proc_id      int(11) NOT NULL,
    existencias  int(11) DEFAULT 0
);

CREATE TABLE banners (
    id               int(11) PRIMARY KEY AUTO_INCREMENT,
    nombre           varchar(70) NOT NULL,
    imagen           varchar(200) NOT NULL,
    cat_id           int(11) NOT NULL
);

CREATE TABLE ato_comprados (
    ato_id        int(11) NOT NULL,
    numero_de_ato int(11) NOT NULL,
    clte_id       int(11) NOT NULL,
    precio        int(11) NOT NULL
);

ALTER TABLE ato_comprados ADD CONSTRAINT ato_cpdo_pk PRIMARY KEY ( ato_id,
                                                                clte_id );

CREATE TABLE categorias (
    id               int(11) PRIMARY KEY AUTO_INCREMENT,
    categoria        varchar(100) NOT NULL,
    estado           varchar(70) NOT NULL
);

CREATE TABLE clientes (
    id               int(11) PRIMARY KEY AUTO_INCREMENT,
    nombre           varchar(70) NOT NULL,
    apellido_paterno varchar(70) NOT NULL,
    celular          varchar(50) NOT NULL,
    correo           varchar(70) NOT NULL,
    contraseña       char(60) NOT NULL,
    foto_de_perfil   varchar(200)
);

CREATE TABLE colores (
    id          int(11) PRIMARY KEY AUTO_INCREMENT,
    color       varchar(70) NOT NULL,
    hexadecimal varchar(70) NOT NULL
);

CREATE TABLE compras (
    clave        int(11) PRIMARY KEY AUTO_INCREMENT,
    fecha        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    direccion_envio varchar(70) NOT NULL,
    tipo_de_entrega varchar(70) NOT NULL,
    estado_compra   varchar(70) NOT NULL,
    total        decimal(10,2) NOT NULL,
    cee_id       int(11) NOT NULL
);


CREATE TABLE direcciones (
    id              int(11) PRIMARY KEY AUTO_INCREMENT,
    calle_y_numero  varchar(70) NOT NULL,
    numero_interior int(10),
    colonia         varchar(70) NOT NULL,
    ciudad          varchar(70) NOT NULL,
    codigo_postal   varchar(70) NOT NULL,
    alias           varchar(70),
    cee_id          int(11) NOT NULL
);


CREATE TABLE empleados (
    id               int(11) PRIMARY KEY AUTO_INCREMENT,
    nombre           varchar(70) NOT NULL,
    apellido_paterno varchar(70) NOT NULL,
    apellido_materno varchar(70) NOT NULL,
    celular          varchar(50) NOT NULL,
    correo           varchar(70) NOT NULL,
    contraseña       char(60) NOT NULL,
    calle_y_numero   varchar(70) NOT NULL,
    numero_interior  int(10),
    colonia          varchar(70) NOT NULL,
    codigo_postal    int(10) NOT NULL,
    ciudad           varchar(70) NOT NULL,
    sueldo           decimal(10,2) NOT NULL,
    puesto           varchar(70) NOT NULL,
    foto_de_perfil   varchar(200),
    epo_id           int(1) NOT NULL
);

CREATE TABLE pedidos (
    id                   int(11) PRIMARY KEY AUTO_INCREMENT,
    fecha_y_hora         DATETIME DEFAULT CURRENT_TIMESTAMP,
    epo_id               int(11) NOT NULL
);


CREATE TABLE pro_pedidos (
    numero_de_pro int(10) NOT NULL,
    pdo_id        int(10) NOT NULL,
    mta_prima_id  int(10) NOT NULL
);

ALTER TABLE pro_pedidos ADD CONSTRAINT pro_pdo_pk PRIMARY KEY ( pdo_id,
                                                                mta_prima_id );

CREATE TABLE mta_primas (
    id                  int(11) PRIMARY KEY AUTO_INCREMENT,
    nombre_de_proveedor varchar(70) NOT NULL,
    tipo_de_mta_prima   varchar(70) NOT NULL,
    talla               varchar(70),
    unidad_de_medida    varchar(100),
    precio              int(11) NOT NULL,
    existencias         decimal(10,2) DEFAULT 0,
    col_id              int(11)
);

CREATE TABLE material_utilizado (
    ato_id        int(11) NOT NULL,
    mta_prima_id  int(11) NOT NULL,
    cantidad      decimal(10,2) NOT NULL
);

ALTER TABLE material_utilizado ADD CONSTRAINT mtal_utdo_pk PRIMARY KEY ( ato_id,
                                                                mta_prima_id);

CREATE TABLE procesos (
    id                  int(11) PRIMARY KEY AUTO_INCREMENT,
    nombre_de_proceso   varchar(70) NOT NULL,
    pco_actual          decimal(10,2) NOT NULL
);


CREATE TABLE usuarios(
    id          int(11) PRIMARY KEY AUTO_INCREMENT,
    nombre      varchar(70) NOT NULL,
    correo       varchar(70) NOT NULL,
    contraseña  char(60) NOT NULL,
    tipo        char(1)
);



ALTER TABLE ato_comprados
    ADD CONSTRAINT ato_cpo_ato_fk FOREIGN KEY ( ato_id )
        REFERENCES articulos ( id );

ALTER TABLE ato_comprados
    ADD CONSTRAINT ato_cpo_cee_fk FOREIGN KEY ( clte_id )
        REFERENCES clientes ( id );

ALTER TABLE articulos
    ADD CONSTRAINT ato_cat_fk FOREIGN KEY ( cat_id )
        REFERENCES categorias ( id );

ALTER TABLE banners
    ADD CONSTRAINT bann_cat_fk FOREIGN KEY ( cat_id )
        REFERENCES categorias ( id );

ALTER TABLE compras
    ADD CONSTRAINT cpa_cee_fk FOREIGN KEY ( cee_id )
        REFERENCES clientes ( id );

ALTER TABLE direcciones
    ADD CONSTRAINT drn_cee_fk FOREIGN KEY ( cee_id )
        REFERENCES clientes ( id );

ALTER TABLE empleados
    ADD CONSTRAINT epo_epo_fk FOREIGN KEY ( epo_id )
        REFERENCES empleados ( id );                    

ALTER TABLE pedidos
    ADD CONSTRAINT pdo_epo_fk FOREIGN KEY ( epo_id )
        REFERENCES empleados ( id );

ALTER TABLE pro_pedidos
    ADD CONSTRAINT pro_pdo_pdo_fk FOREIGN KEY ( pdo_id )
        REFERENCES pedidos ( id );

ALTER TABLE pro_pedidos
    ADD CONSTRAINT pro_pdo_pro_fk FOREIGN KEY ( mta_prima_id )
        REFERENCES mta_primas ( id );

ALTER TABLE material_utilizado
    ADD CONSTRAINT mtal_utdo_ato_fk FOREIGN KEY ( ato_id )
        REFERENCES articulos ( id );

ALTER TABLE material_utilizado
    ADD CONSTRAINT mtal_utdo_mta_prima_fk FOREIGN KEY ( mta_prima_id )
        REFERENCES mta_primas ( id );      

ALTER TABLE mta_primas
    ADD CONSTRAINT mta_prima_col_fk FOREIGN KEY ( col_id )
        REFERENCES colores ( id ); 

ALTER TABLE articulos
    ADD CONSTRAINT ato_proc_fk FOREIGN KEY ( proc_id )
        REFERENCES procesos ( id );

ALTER TABLE articulos
    ADD CONSTRAINT ato_col_fk FOREIGN KEY ( col_id )
        REFERENCES colores ( id );


INSERT INTO `clientes` (id,nombre,apellido_paterno,celular,correo,contraseña) VALUES (1,'Wesley','Mendoza','2221628211','wesley3004@hotmail.com','$2y$10$YEqG.s8uCRaJUK91JRIaRuOipmTIvPrBr4aKNvl3bRP6TVRo6NS0O'),(2,'Samatha','Ramirez','2211343733','samanthakhj23@gmail.com','$2y$10$5FgWwi80RB50VIlDxVLFQ.B/PF7sAeh5UDU6megxfbcfQv5s54zzC'),(3,'Alfonso','Mendoza','2211117859','victormendoza@gmail.com','$2y$10$7G/y6euGUfaRPTQ0NtoGdO8VZwk9gGNqJMk68ju3FX5iLcWTHSzZS');

INSERT INTO `empleados` (id,nombre,apellido_paterno,apellido_materno,celular,correo,contraseña,calle_y_numero,numero_interior,colonia,codigo_postal,ciudad,sueldo,puesto,epo_id) VALUES (1,'Benjamin Wesley','Mendoza','Gómez','2221628234','benjaminwesley.mendoza@upaep.edu.mx','$2y$10$O2vGsPl98fRQNou/TN3ka.uEc39HBLfTeo9xEN24vZH2/J6Y1ipLq','Av. Hidalgo 320',NULL,'La Libertad',72130,'Puebla',30000.00,'Administrador',1),(2,'Calidad','Clase','Clase','2211111111','calidad@gmail.com','Pruebadecalidad','Av. Hidalgo 320',NULL,'La Libertad',72130,'Puebla',30000.00,'Administrador',1);

INSERT INTO `usuarios` VALUES (1,'Benjamin Wesley','benjaminwesley.mendoza@upaep.edu.mx','$2y$10$O2vGsPl98fRQNou/TN3ka.uEc39HBLfTeo9xEN24vZH2/J6Y1ipLq','A'),(2,'Wesley','wesley3004@hotmail.com','$2y$10$YEqG.s8uCRaJUK91JRIaRuOipmTIvPrBr4aKNvl3bRP6TVRo6NS0O','C'),(3,'Samatha','samanthakhj23@gmail.com','$2y$10$5FgWwi80RB50VIlDxVLFQ.B/PF7sAeh5UDU6megxfbcfQv5s54zzC','A'),(4,'Alfonso','victormendoza@gmail.com','$2y$10$7G/y6euGUfaRPTQ0NtoGdO8VZwk9gGNqJMk68ju3FX5iLcWTHSzZS','C');

INSERT INTO `procesos` VALUES (1,'Serigrafia',200.00);
