# CalistoShop

## Tareas Pendientes

- Empleado -> Felipe :heavy_check_mark:
- Articulo -> Felipe :heavy_check_mark:
- Estado Precio -> Felipe :heavy_check_mark:
- Material Utilizado -> Felipe :heavy_check_mark:

- Cliente -> Wesley :heavy_check_mark:
- Compra -> Wesley :heavy_check_mark:
- Proceso -> Wesley
- Articulo Comprado -> Wesley

- Direccion -> Wesley  :heavy_check_mark:
- Pedido -> Victor :heavy_check_mark:
- Materia Prima -> Victor
- Producto Pedido -> Victor
