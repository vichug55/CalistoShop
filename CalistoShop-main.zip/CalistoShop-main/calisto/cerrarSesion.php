<?php
  session_start();
  $_SESSION=[];
  header('Location: /proyectos/2023/Calisto_Shop/index.php');