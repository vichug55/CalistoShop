<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="estilos/normalize.css">
    <link href="https://fonts.googleapis.com/css2?family=Staatliches&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="estilos/styles.css">
    <link rel="shortcut icon" href="imagenes/logo.png">
    <title>Calisto Shop</title>
</head>
<body>
       <?php
            $fecha=$_GET["fecha"];
            $hora=$_GET["hora"];
            $cobro=$_GET["cobro"];
            $numProductos=$_GET["numProductos"];
        ?>
    <header class="header">
        <a href="index.html">
            <img class="header__logo" src="imagenes/logo.png" alt="Logotipo">
        </a>
    </header>
    
    <nav class="navegacion">
        <a class="navegacion__enlace" >Empleados</a>
        <a class="navegacion__enlace" >Pedidos</a>
        <a class="navegacion__enlace" >Productos</a>
        <a class="navegacion__enlace" >Compras</a>
        <a class="navegacion__enlace" >Inventario</a>
        
    </nav>

    <h3>Pedidos</h3>

    <div class="content principal--empleado">
        <div class="usuario">
            <div class="img_usu">
                <img src="imagenes/paquete-removebg-preview.png">
            </div>
        </div>

        <main class="info">
            <h2 class="info">Fecha: <span class="usurioR"><?php echo $fecha; ?></span></h2><br>
            <h2 class="info">Hora: <span class="usurioR"><?php echo $hora; ?></span></h2><br>
            <h2 class="info">Cobro total: <span class="usurioR"><?php echo $cobro; ?></span></h2><br>
            <h2 class="info">Cantidad de productos: <span class="usurioR"><?php echo $numProductos; ?></span></h2><br>
        </main>

    </div>
    

    <footer class="footer">
        <p class="footer__texto">Footer</p>
    </footer>

</body>
</html>