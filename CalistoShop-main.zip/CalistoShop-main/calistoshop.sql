-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: calistoshop
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `articulos`
--

LOCK TABLES `articulos` WRITE;
/*!40000 ALTER TABLE `articulos` DISABLE KEYS */;
INSERT INTO `articulos` VALUES (1,'Shazam Nuevo','Playeras','Playera sencilla del personaje shazam','Cuello V','Morado','S',1,50);
/*!40000 ALTER TABLE `articulos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `ato_comprados`
--

LOCK TABLES `ato_comprados` WRITE;
/*!40000 ALTER TABLE `ato_comprados` DISABLE KEYS */;
/*!40000 ALTER TABLE `ato_comprados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES (1,'Wesley','Mendoza','2221628299','wesley3004@hotmail.com','$2y$10$e1vHqLeLT0r25wYb8kQMLewpcbpUQ4ybEmW4FVmfhQ55.crKRQFp.'),(2,'Wesley','Mendoza','2221628299','wesley3004@hotmail.com','$2y$10$eqrxOAmTK.OHOhpyqnJdneakULiE2pQloFXhQmE6nTzxvr5IhKpRO');
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `compras`
--

LOCK TABLES `compras` WRITE;
/*!40000 ALTER TABLE `compras` DISABLE KEYS */;
/*!40000 ALTER TABLE `compras` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `direcciones`
--

LOCK TABLES `direcciones` WRITE;
/*!40000 ALTER TABLE `direcciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `direcciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `empleados`
--

LOCK TABLES `empleados` WRITE;
/*!40000 ALTER TABLE `empleados` DISABLE KEYS */;
INSERT INTO `empleados` VALUES (1,'Benjamin Wesley','Mendoza','Gómez','2221628234','benjaminwesley.mendoza@upaep.edu.mx','$2y$10$iBWKWqK8JmUnkqnj9Fwl7uiPoSnpIggxH74aR8jFem80Y3XdUwg16','Av. Hidalgo 320',NULL,'La Libertad',72130,'Puebla',30000.00,'Administrador',1);
/*!40000 ALTER TABLE `empleados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `eto_precios`
--

LOCK TABLES `eto_precios` WRITE;
/*!40000 ALTER TABLE `eto_precios` DISABLE KEYS */;
/*!40000 ALTER TABLE `eto_precios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `mta_primas`
--

LOCK TABLES `mta_primas` WRITE;
/*!40000 ALTER TABLE `mta_primas` DISABLE KEYS */;
INSERT INTO `mta_primas` VALUES (1,'Alibaba','Telas Vinil','Morado','','','Kg');
/*!40000 ALTER TABLE `mta_primas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `pedidos`
--

LOCK TABLES `pedidos` WRITE;
/*!40000 ALTER TABLE `pedidos` DISABLE KEYS */;
/*!40000 ALTER TABLE `pedidos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `pro_pedidos`
--

LOCK TABLES `pro_pedidos` WRITE;
/*!40000 ALTER TABLE `pro_pedidos` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_pedidos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `procesos`
--

LOCK TABLES `procesos` WRITE;
/*!40000 ALTER TABLE `procesos` DISABLE KEYS */;
INSERT INTO `procesos` VALUES (1,'Sublimado',200.00);
/*!40000 ALTER TABLE `procesos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'Benjamin Wesley','benjaminwesley.mendoza@upaep.edu.mx','$2y$10$iBWKWqK8JmUnkqnj9Fwl7uiPoSnpIggxH74aR8jFem80Y3XdUwg16','A'),(2,'Victor','victorhugo.ramirez@upaep.edu.mx','$2y$10$e1vHqLeLT0r25wYb8kQMLewpcbpUQ4ybEmW4FVmfhQ55.crKRQFp.','C'),(3,'Froylan','vic@gmail.com','$2y$10$MeGvRVQSAsviZijmVT6mZupi2oD33ROAXWM09oM1lJy0MgLCf4xFC','E'),(4,'Wesley','wesley3004@hotmail.com','$2y$10$eqrxOAmTK.OHOhpyqnJdneakULiE2pQloFXhQmE6nTzxvr5IhKpRO','C'),(5,'Pedro','vic@gmail.com','$2y$10$XMTq/34fejtITD2OJ.Xxn.SbtK8x/qhOUyh3Dluv2WIE/fR9KB9My','E');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-03-29 11:13:41
