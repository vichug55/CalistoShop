<?php
  session_start();
  $_SESSION=[];
  header('Location: /calistoshop/index.php');